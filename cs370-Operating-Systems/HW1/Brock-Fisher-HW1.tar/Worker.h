// file to define Worker functions to be called in Initiator


// function needing called to calculate the running ratio
float get_running_ratio();



