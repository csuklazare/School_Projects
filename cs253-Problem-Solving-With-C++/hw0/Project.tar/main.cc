#include <iostream>
        using namespace std;

        int main() {
            // How many CU students does it take to change a light bulb?
            cout << "1, to call the electrician.\n";
            return 0;
        }
